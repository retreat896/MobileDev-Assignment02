from fastapi import FastAPI
from pymongo import MongoClient
from bson import ObjectId
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pathlib import Path
# --- MongoDB connection ---
uri = "mongodb+srv://krus:KrustyPassword@mycluster.7qdmbzp.mongodb.net/"
client = MongoClient(uri)
db = client["MyDB"] # Database name
collection = db["MyCollection"] # Collection name (not robots.json, just robots)
# --- FastAPI app setup ---
app = FastAPI()
# Optional: enable CORS if you’ll connect from React/React Native
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # or specify your frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# --- Root endpoint ---
@app.get("/")
def read_root():
    path = Path(__file__).resolve().parent / "index.html"
    return FileResponse(path, media_type="text/html")
# --- Get all robots ---
@app.get("/robots")
def get_robots():
    robots = list(collection.find()) # Retrieve all documents
    for r in robots:
        r["_id"] = str(r["_id"]) # Convert ObjectId to string
    return robots
